$('.slider').slick({
     infinite: true,
     slideToShoe:1,
     slideToScroll:1
});